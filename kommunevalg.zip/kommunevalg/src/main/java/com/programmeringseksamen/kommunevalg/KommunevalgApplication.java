package com.programmeringseksamen.kommunevalg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KommunevalgApplication {

    public static void main(String[] args) {
        SpringApplication.run(KommunevalgApplication.class, args);
    }

}
