package com.programmeringseksamen.kommunevalg.model;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class Kandidat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
        private int kandidatID;
        private String kandidat;
        private String parti;

    public Kandidat() {
    }

    public int getKandidatID() {
        return kandidatID;
    }

    public void setKandidatID(int kandidatID) {
        this.kandidatID = kandidatID;
    }

    public String getKandidat() {
        return kandidat;
    }

    public void setKandidat(String kandidat) {
        this.kandidat = kandidat;
    }

    public String getParti() {
        return parti;
    }

    public void setParti(String parti) {
        this.parti = parti.toUpperCase();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Kandidat kandidat1 = (Kandidat) o;
        return kandidatID == kandidat1.kandidatID && Objects.equals(kandidat, kandidat1.kandidat) && Objects.equals(parti, kandidat1.parti);
    }

    @Override
    public int hashCode() {
        return Objects.hash(kandidatID, kandidat, parti);
    }

    @Override
    public String toString() {
        return "Kandidat{" +
                "kandidatID=" + kandidatID +
                ", kandidat='" + kandidat + '\'' +
                ", parti='" + parti + '\'' +
                '}';
    }
}

