package com.programmeringseksamen.kommunevalg.controller;

import com.programmeringseksamen.kommunevalg.model.Kandidat;
import com.programmeringseksamen.kommunevalg.repository.KandidatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(value = "*")
public class RESTcontrollerKommuneValg {

    @Autowired
    KandidatRepository kandidatRepository;

    @PostMapping(value="/kandidat", consumes = "application/json")
    public ResponseEntity<Kandidat> newKandidat(@RequestBody Kandidat kandidat) {
        System.out.println("Kandidat = " + kandidat);
        kandidatRepository.save(kandidat);
        System.out.println("Kandidat er saved = " + kandidat);
        return new ResponseEntity<Kandidat>(kandidat, HttpStatus.CREATED);
    }

    @GetMapping("/kandidater")
    public List<Kandidat> allKandidater() {
        return kandidatRepository.findAll();
    }

    @GetMapping("/kandidat/{id}")
    public Kandidat getKommune(@PathVariable int id) {
        Optional<Kandidat> obj = kandidatRepository.findById(id);
        if (obj.isPresent()) {
            return obj.get();
        }
        Kandidat kandidat = new Kandidat();
        kandidat.setKandidat ("Not Found");
        return kandidat;
    }

    // HER ER REST API DER KAN VISE KANDIDATER FRA ET GIVENT PARTI
    // Fx http://localhost:8080/parti/a
    @GetMapping("/parti/{partibogstav}")
    public List<Kandidat> allKandidaterByParti(@PathVariable String partibogstav) {
        return kandidatRepository.findKandidatByParti(partibogstav);
    }

    @DeleteMapping("kandidat/{id}")
    public ResponseEntity<Object> deleteKandidat(@PathVariable int id) {
        System.out.println("Delete kaldt kandidatID=" + id);
        try {
            kandidatRepository.deleteById(id);
        } catch (Exception err) {
            return new ResponseEntity<>("Kandidat ikke fundet", HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PutMapping("/kandidat/{kandidatID}")
    public ResponseEntity<Kandidat> updateKandidat(@PathVariable int kandidatID, @RequestBody Kandidat kandidat) {
        System.out.println(kandidatID);
        Optional<Kandidat> kandidatData = kandidatRepository.findById(kandidatID);
        if (kandidatData.isPresent()) {
            Kandidat _kandidat = kandidatData.get();
            _kandidat.setKandidat(kandidat.getKandidat()); //her sættes navn
            _kandidat.setParti(kandidat.getParti()); //her sættes parti
            _kandidat = kandidatRepository.save(_kandidat);
            return new ResponseEntity<>(_kandidat, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


}
