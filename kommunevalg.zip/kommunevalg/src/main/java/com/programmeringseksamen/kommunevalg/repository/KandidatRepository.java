package com.programmeringseksamen.kommunevalg.repository;

import com.programmeringseksamen.kommunevalg.model.Kandidat;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface KandidatRepository extends JpaRepository <Kandidat, Integer> {

    List<Kandidat> findKandidatByParti(String parti);

}
