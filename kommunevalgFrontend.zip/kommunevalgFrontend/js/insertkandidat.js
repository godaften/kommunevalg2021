const out = (str) => console.log(str);

document.addEventListener("DOMContentLoaded", createFormEventListener);

let kandidatForm;

function createFormEventListener() {
  kandidatForm = document.getElementById("newKandidatForm");
  kandidatForm.addEventListener("submit", handleFormSubmit);
}

async function handleFormSubmit(event) {
  event.preventDefault();
  out(event);

  const form = event.currentTarget;
  const url = form.action;
  out(form);
  out(url);

  try {
    const formData = new FormData(form);
    const responseData = await restInsertKandidat(url, formData);
    out("responseData=");
    out(responseData)
  } catch (error) {
    alert(error.message);
    out(error);
  }
}


async function restInsertKandidat(url, formData) {

  const plainFormData = Object.fromEntries(formData.entries());

  // out(plainFormData);

  const jsonString = JSON.stringify(plainFormData);

  const fetchOptions = {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: jsonString
  }

  const response = await fetch(url, fetchOptions);

  if (!response.ok) {
    out("Noget gik galt!");
  }

  return response.json();

}





