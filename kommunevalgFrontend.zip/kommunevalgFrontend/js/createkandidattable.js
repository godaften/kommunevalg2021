const table = document.getElementById("kandidat_tabel");

function addRow(kandidat) {
  let rowCount = table.rows.length;
  let row = table.insertRow(rowCount);
  row.id = kandidat.kandidat;


  // KANDIDATID
  let cell0 = row.insertCell(0);
  cell0.innerHTML = kandidat.kandidatID;


  // KANDIDATNAVN I INPUTFELT
  let cell1 = row.insertCell(1);
  let kanInp = document.createElement("input");
  kanInp.type = "text";
  kanInp.setAttribute("value", kandidat.kandidat);
  cell1.appendChild(kanInp);


  // PARTI I INPUTFELT
  let cell2 = row.insertCell(2);
  let kan1Inp = document.createElement("input");
  kan1Inp.type = "text";
  kan1Inp.setAttribute("value", kandidat.parti);
  cell2.appendChild(kan1Inp);


  // SLET KANDIDAT
  let cell3 = row.insertCell(3);
  let pbDelete = document.createElement("input");
  pbDelete.type = "button";
  pbDelete.setAttribute("value", "Slet kandidat");
  pbDelete.onclick = function() {
    document.getElementById(kandidat.kandidat).remove();
    //table.deleteRow(0);
    deleteKandidat(kandidat); // HVAD sker der her? Promise ignored?
  }
  cell3.appendChild(pbDelete);


  // REDIGER/OPDATER
  let cell4 = row.insertCell(4);
  let pbUpdate = document.createElement("input");
  pbUpdate.type = "button";
  pbUpdate.setAttribute("value", "Ret kandidat");
  pbUpdate.onclick = function() {
    kandidat.kandidat = kanInp.value;
    kandidat.parti = kan1Inp.value
    updateKandidat(kandidat);
  }
  cell4.appendChild(pbUpdate);
}


async function updateKandidat(kandidat) {
  try {
    const response = await restUpdateKandidat(kandidat);
    out(response);

  } catch(error) {
    alert(error.message);
    out(error);
  }
}

async function restUpdateKandidat(kandidat) {
  const url = "http://localhost:8080/kandidat/" + kandidat.kandidatID;
  const jsonString = JSON.stringify(kandidat);
  out(jsonString);

  const fetchOptions = {
    method: "PUT",
    headers: {
      "Content-Type": "application/json"
    },
    body: jsonString
  }
  const response = await fetch(url, fetchOptions);
  out("Vi har rettet");
  out(response.status);
  out(response.ok);
  if (!response.ok) {
    out("Noget gik galt!");
  }
  return response.json();
}

async function deleteKandidat(kandidat) {
  try {
    const response = await restDeleteKandidat(kandidat);
    out(response);

  } catch(error) {
    alert(error.message);
    out(error);
  }
}

async function restDeleteKandidat(kandidat) {
  const url = "http://localhost:8080/kandidat/" + kandidat.kandidatID;

  const fetchOptions = {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json"
    },
    body: ""
  }

  const response = await fetch(url, fetchOptions);

  if (!response.ok) {
   out("Noget gik galt!");
  }

  return response;
  {
    location.reload();
  };
}

function createTableFromMap() {
  clearTable(table);
  for (const kanKey of kandidatMap.keys()) {
    const kandidat1 = kandidatMap.get(kanKey);
    addRow(kandidat1);
  }
}

// Tømmer tabel minus overskrifter
function clearTable(table) {
  var rows = table.rows;
  var i = rows.length;
  while (--i) {
    rows[i].parentNode.removeChild(rows[i]);
  }
}

const pbCreateTable = document.querySelector(".pbCreateTable");
pbCreateTable.addEventListener("click",createTableFromMap);



