const out = (str) => console.log(str);

const kanUrl = "http://localhost:8080/kandidater";

function fetchAllKandidater() {
  return fetch(kanUrl, {cache: "no-store"}).then(response => response.json());
}

function callFetchAllKandidater() {
  const prom = fetchAllKandidater();
  prom.then(createKandidatMap);
}

let kandidatMap = new Map();
function createKandidatMap(data) {
  data.forEach(kan => {
    out(data);
    kandidatMap.set(kan.kandidat, kan);
  })
}

function showKandidatMap() {
  for (const kanKey of kandidatMap.keys()) {
    out(kandidatMap.get(kanKey));
  }
}

const pbGetKandidater = document.querySelector(".pbGet");
const pbShowMap = document.querySelector(".pbShowKandidatMap");

pbGetKandidater.addEventListener("click", callFetchAllKandidater);
pbShowMap.addEventListener("click", showKandidatMap);







